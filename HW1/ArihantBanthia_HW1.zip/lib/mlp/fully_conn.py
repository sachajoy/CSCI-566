from __future__ import absolute_import, division, print_function

from lib.mlp.layer_utils import *

""" Super Class """


class Module(object):
    def __init__(self):
        self.params = {}
        self.grads = {}

    def forward(self, feat, is_training=True, seed=None):
        output = feat
        for layer in self.net.layers:
            if isinstance(layer, dropout):
                output = layer.forward(output, is_training, seed)
            else:
                output = layer.forward(output)
        self.net.gather_params()
        return output

    def backward(self, dprev):
        for layer in self.net.layers[::-1]:
            dprev = layer.backward(dprev)
        self.net.gather_grads()
        return dprev


""" Classes """


class TestFCReLU(Module):
    def __init__(self, keep_prob=0, dtype=np.float32, seed=None):
        self.net = sequential(
            #### TODO: Add the layers ####
            flatten(name="flat"),
            fc(15, 5, 5e-2, name="fc"),
            leaky_relu(name="relu")
            ############# END ############
        )


class SmallFullyConnectedNetwork(Module):
    def __init__(self, keep_prob=0, dtype=np.float32, seed=None):
        self.net = sequential(
            #### TODO: Add the layers ####
            flatten(name="flat"),
            fc(4, 30, 2e-2, name="fc1"),
            leaky_relu(name="relu1"),
            fc(30, 7, 2e-2, name="fc2"),
            ############# END ############
        )


class DropoutNet(Module):
    def __init__(self, keep_prob=0, dtype=np.float32, seed=None):
        self.dropout = dropout
        self.seed = seed
        self.net = sequential(
            flatten(name="flat"),
            fc(15, 20, 5e-2, name="fc1"),
            leaky_relu(name="relu1"),
            fc(20, 30, 5e-2, name="fc2"),
            leaky_relu(name="relu2"),
            fc(30, 10, 5e-2, name="fc3"),
            leaky_relu(name="relu3"),
            dropout(keep_prob, seed=seed),
        )


class TinyNet(Module):
    def __init__(self, keep_prob=0, dtype=np.float32, seed=None):
        """Some comments"""
        self.net = sequential(
            #### TODO: Add the layers ####
            flatten(name="flat"),
            fc(3072, 300, 2e-2, name="fc1"),
            leaky_relu(name="relu1"),
            fc(300, 10, 2e-2, name="fc2"),
            ############# END ############
        )


class DropoutNetTest(Module):
    def __init__(self, keep_prob=0, dtype=np.float32, seed=None):
        """Some comments"""
        self.dropout = dropout
        self.seed = seed
        self.net = sequential(
            flatten(name="flat"),
            fc(3072, 500, 1e-2, name="fc1"),
            dropout(keep_prob, seed=seed),
            leaky_relu(name="relu1"),
            fc(500, 500, 1e-2, name="fc2"),
            leaky_relu(name="relu2"),
            fc(500, 10, 1e-2, name="fc3"),
        )


class FullyConnectedNetwork(Module):
    def __init__(self, keep_prob=0, dtype=np.float32, seed=None):
        """Some comments"""
        self.net = sequential(
            flatten(name="flat"),
            fc(3072, 100, 5e-2, name="fc1"),
            leaky_relu(name="relu1"),
            fc(100, 100, 5e-2, name="fc2"),
            leaky_relu(name="relu2"),
            fc(100, 100, 5e-2, name="fc3"),
            leaky_relu(name="relu3"),
            fc(100, 100, 5e-2, name="fc4"),
            leaky_relu(name="relu4"),
            fc(100, 100, 5e-2, name="fc5"),
            leaky_relu(name="relu5"),
            fc(100, 10, 5e-2, name="fc6"),
        )
